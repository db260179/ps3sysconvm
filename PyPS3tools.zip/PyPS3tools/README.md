# PyPS3tools
Suite of python tools for PS3 flash memory dump files.

Disclaimer:
----------
WARNING: Use those softwares at your own risk. The author accepts no
responsibility for the consequences of your use of them.


Check the readme of each folders for details.

Note: Windows users can use the Standalone Packages instead of python scripts (no need to install python in that case)


Thanks to all PS3 dev. community.
Many thanks to LS beta testers ;)


